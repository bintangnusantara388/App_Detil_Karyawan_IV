<!DOCTYPE html>
<html>
<head>
    <title>detil karyawan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>
<body>
   
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php echo $__env->yieldContent('scripts'); ?> 
</body>
</body>
</html><?php /**PATH D:\application\coba-laravel\resources\views/detil_karyawan/layout.blade.php ENDPATH**/ ?>