
<?php $__env->startSection('content'); ?>
<div class="container">
<?php if(session()->has('loginSuccess')): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
            <?php echo e(session('loginSuccess')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session()->has('flash_message')): ?>
    <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
        <?php echo e(session('flash_message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session()->has('error_message')): ?>
    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
        <?php echo e(session('error_message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="row" style="margin:50px;">
        <div class="col-14">
            <div class="card">
                <div class="card-header">
                    <h2>DETIL KARYAWAN</h2>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(url('detil_karyawan/create')); ?>" class="btn btn-success" title="Add New detil_karyawan"><i class="fas fa-plus"></i>Add new</a>
                    <form action="/logout" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger mt-3"><i class="bi bi-box-arrow-right"></i>logout</button>
                    </form>
                    <br/>
                    <br/>
                    <div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Kode Karyawan Detail</th>
                <th scope="col">Kode Karyawan</th>
                <th scope="col">Nomor KTP</th>
                <th scope="col">Tempat Lahir</th>
                <th scope="col">Tanggal Lahir</th>
                <th scope="col">Alamat KTP</th>
                <th scope="col">Kota KTP</th>
                <th scope="col">Provinsi KTP</th>
                <th scope="col">Kode pos KTP</th>
                <th scope="col">Nomor Telepon</th>
                <th scope="col">Email</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <?php
                $no = 1;
            ?>

        <?php $__currentLoopData = $detil_karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody class="table-group-divider">

            <tr>
                <th scope="row"><?php echo e($no++); ?></th>
                <td><?php echo e($item->kode_karyawan_detail); ?></td>
                <td><?php echo e($item->kode_karyawan); ?></td>
                <td><?php echo e($item->nomor_ktp); ?></td>
                <td><?php echo e($item->tempat_lahir); ?></td>
                <td><?php echo e($item->tanggal_lahir); ?></td>
                <td><?php echo e($item->alamat_ktp); ?></td>
                <td><?php echo e($item->kota_ktp); ?></td>
                <td><?php echo e($item->provinsi_ktp); ?></td>
                <td><?php echo e($item->kode_pos_ktp); ?></td>
                <td><?php echo e($item->nomor_telepon); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td>
                    <div class="d-flex">
                        <a href="<?php echo e(route('detil_karyawan.show', $item->kode_karyawan_detail)); ?>" class="btn btn-info me-2"><i class="bi bi-eye"></i>Show</a>
                        <a href="<?php echo e(route('detil_karyawan.edit', $item->kode_karyawan_detail)); ?>" class="btn btn-primary me-2"><i class="bi bi-pencil-square"></i>Edit</a>
                        <form method="POST" action="<?php echo e(route('detil_karyawan.destroy', $item->kode_karyawan_detail)); ?>" style="display:inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Student" onclick="return confirm('Confirm delete?')"><i class="bi bi-trash3"></i> Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var alert = document.querySelector('.alert');
            if (alert) {
                var closeButton = alert.querySelector('.btn-close');
                closeButton.addEventListener('click', function() {
                    alert.style.display = 'none';
                });
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 3000);
            }
        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('detil_karyawan.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\application\coba-laravel\resources\views/detil_karyawan/index.blade.php ENDPATH**/ ?>